---
name: "vibecoding-llmwiki"
description: "AdaWeldSystem LLMWiki-native vibecoding workflow. When user inputs /vibeCoding or asks for code development/bug fix/feature implementation, this skill forces AI to execute Phase 0~4 workflow with LLMWiki as the single source of truth."
version: "1.3.0"
agent_created: true
---

# /vibeCoding -- LLMWiki Native Workflow (WorkBuddy Edition)

> **core**: LLMWiki is the single source of truth. Before coding, Query the Wiki for context. After coding, Ingest knowledge back into the Wiki. Skill specs in `raw/skills/` are reference material only, not the command center.

## Workspace Path Map

All paths in this skill are relative to the workspace root:

```
WORKSPACE_ROOT = D:\A-A-项目类\04_研发项目\MRDF-2608 自适应焊接系统\workbudddy
```

| Logical Name | Actual Path (relative to workspace) |
|---|---|
| LLMWiki Root | `Vicoding管理平台/LLMWiki/` |
| AGENTS.md | `Vicoding管理平台/LLMWiki/AGENTS.md` |
| Workflow Spec | `Vicoding管理平台/LLMWiki/wiki/project/vibecoding-workflow.md` |
| Wiki Index | `Vicoding管理平台/LLMWiki/wiki/index/index.md` |
| Wiki Log | `Vicoding管理平台/LLMWiki/logs/log.md` |
| Decisions (ADR) | `Vicoding管理平台/LLMWiki/wiki/decisions/` |
| Lessons | `Vicoding管理平台/LLMWiki/wiki/lessons/` |
| Modules | `Vicoding管理平台/LLMWiki/wiki/modules/` |
| API Docs | `Vicoding管理平台/LLMWiki/wiki/api/` |
| People | `Vicoding管理平台/LLMWiki/wiki/people/` |
| Raw Skills | `Vicoding管理平台/LLMWiki/raw/skills/AdaWeldsys_Skills/` |
| C# Style Guide | `Vicoding管理平台/LLMWiki/raw/skills/AdaWeldsys_Skills/04-Style/CSharpStyle.md` |
| History | `Vicoding管理平台/LLMWiki/raw/history/history.md` |
| Code Project | `AdaWeldSystem/AdaWeldSystem.csproj` |
| Code Root | `AdaWeldSystem/` |

## Trigger Conditions (Forced Match)

When the user inputs any of the following, this skill **must** be triggered:
- `/vibeCoding` or `/vibecoding` (case insensitive)
- Explicit development need: "develop a feature", "implement a requirement", "create a module"
- Explicit fix need: "fix a bug", "solve a problem"
- Explicit optimization need: "optimize a feature", "refactor code"

## Execution Priority (Forced)

Upon receiving `/vibeCoding` or equivalent intent, **do not** start coding directly or freely read files. Execute in the following order:

1. **Read LLMWiki workflow spec** (forced step 1):
   - Path: `Vicoding管理平台/LLMWiki/wiki/project/vibecoding-workflow.md`
   - Action: **must use the Read tool to read the full content**
   - If not found: log error and stop, prompt user "LLMWiki workflow file missing, cannot execute /vibeCoding"

2. **Read AGENTS.md supplementary rules** (forced step 2):
   - Path: `Vicoding管理平台/LLMWiki/AGENTS.md`
   - Action: Read the `/vibeCoding Workflow (LLMWiki Native)` section

3. **Execute Phase 0~4 strictly** (forced step 3):
   - Follow `vibecoding-workflow.md` Phase 0 -> Phase 1 -> Phase 2 -> Phase 3 -> Phase 4
   - **Each Phase must be executed Step-by-Step** (Step 0.1 -> 0.2 -> ... -> Step 4.x)
   - After each Phase, report results to user, get confirmation before proceeding

4. **Use TaskCreate/TaskUpdate for phase tracking**:
   - Create a task for each Phase before starting it
   - Mark task as `in_progress` when starting, `completed` when done

5. **Step-Level Display Rule (FORCED, Non-bypassable)**:
   - **Every Step must be explicitly shown to the user** with its number, name, and output
   - Display format: `### Step X.Y: StepName` followed by a concise output summary
   - **PROHIBITED**: Only showing Phase-level summaries without Step-level breakdown
   - **PROHIBITED**: Collapsing multiple Steps into a single line or summary
   - **PROHIBITED**: Executing Steps silently (reading files / checking constraints) without showing what was done
   - **REQUIRED**: After completing each Step, display the Step number, name, and key findings (files read, constraints found, decisions made, etc.)
   - **REQUIRED**: After completing all Steps within a Phase, show a Phase Summary table BEFORE asking user confirmation
   - **Example of correct output**:
     ```
     ### Step 0.1: Read Index
     - Read `wiki/index/index.md`
     - Related pages found: [[modules/Comm]], [[api/GlobalCommData]]

     ### Step 0.2: Read ADR
     - Read `wiki/decisions/ADR-007-CommRefactor.md`
     - Constraint: TCPIPComm under CommunicationManager
     ```
   - **Example of WRONG output** (prohibited):
     ```
     Phase 0 complete. Found relevant pages.
     ```

## Phase Quick Reference (Forced Execution)

| Phase | Core Action | Required Wiki Paths | Output |
|---|---|---|---|
| **Phase 0: Query** | Knowledge retrieval + code graph | `wiki/index/index.md` -> ADR + Lessons + Modules + API + **codegraph query** | Knowledge retrieval report |
| **Phase 1: Plan** | Planning & constraint confirmation | Based on Phase 0 results | Coding plan (with knowledge ingest forecast) |
| **Phase 2: Code** | Implementation + impact verification | ADR constraints + Lessons gates + **codegraph impact** | Code files |
| **Phase 3: Ingest** | **Forced knowledge deposition** | Update `wiki/modules/`, `wiki/api/`, `wiki/decisions/`, `wiki/lessons/`, `logs/` | Updated Wiki |
| **Phase 4: Lint** | Health check + code drift | Scan contradictions + orphan pages + red links + **codegraph diff** | Health report |

## Key Rules (Forced, Non-bypassable)

1. **No skipping Query**: Before coding, Phase 0 must be executed to retrieve context from LLMWiki. Coding from memory or Skill files alone is prohibited.
2. **Skill demoted to reference**: `raw/skills/` Skill files are **reference material**, not **command source**. Process authority belongs to LLMWiki. If Skill and LLMWiki conflict, LLMWiki prevails.
3. **ADR is hard constraint**: Architecture Decision Records in `wiki/decisions/` are mandatory constraints before coding. After coding, must review to check for violations.
4. **Lessons are gates**: Pitfall records in `wiki/lessons/` are mandatory pre-coding check items. E.g., `[[lessons/CodeProjectRegistration]]` requires new .cs files to be registered to .csproj.
5. **Ingest is mandatory**: Phase 3 Ingest is not optional. Coding without Ingest is considered incomplete.
6. **New decisions must be recorded**: If coding involves new architecture choices, must create ADR in `wiki/decisions/`.
7. **Timestamp rule**: Phase 3 Ingest appending `logs/log.md` must get timestamp via Bash `date "+%Y-%m-%d %H:%M:%S"` or PowerShell `Get-Date -Format "yyyy-MM-dd HH:mm:ss"`. Never estimate. If unable to execute, mark as `[No.]`.
8. **New .csproj registration**: When creating new .cs files, **must** add `<Compile Include="..." />` entries to `AdaWeldSystem/AdaWeldSystem.csproj`.
9. **Step-Level Display (Non-bypassable)**: Every Step within each Phase MUST be explicitly shown to the user with its number, name, and output. Skipping Step-level display is a violation. See Execution Priority section 5 for details.
10. **Code Graph is mandatory (Non-bypassable)**: Per ADR-025, code graph must be used in Phase 0 (Step 0.7 query), Phase 2 (Step 2.5 impact radius), and Phase 4 (code drift detection). Skipping code graph steps is a violation. If code graph tool is unavailable (not installed or build failed), log the issue and fall back to Grep, but the steps must still be executed and shown.

## Critical ADR Constraints (Must Check Before Coding)

| ADR | Constraint |
|---|---|
| ADR-001-DisposePattern | Use `DisposeComponents()` method; **never add or override `Dispose(bool)` in any `.cs` file**; never modify Designer.cs Dispose |
| ADR-002-CS73-Constraint | C# 7.3 only. No auto-property initializer, no expression-body property, no `out var`, no tuple deconstruction (see note below) |
| ADR-003-SingleAlgorithmFile | ImageAlgorithm.cs is the only algorithm file |
| ADR-004-WorkflowStepEnum | Use 7 Step enum, not sequential flow |
| ADR-005-CallbackAcquisition | Workflow image acquisition uses callback wait pattern |
| ADR-006-UILightProperty | UILight must use OnColor/OffColor/State |

> **Note on ADR-002**: The original ADR-002 prohibits `out var` and tuple deconstruction due to MSBuild v4.0. However, the CSharpStyle.md V2.260624 allows `out var` and tuples. **Follow CSharpStyle.md** (the latest authority) for syntax questions. When in doubt, Query the Wiki.

## Critical Lessons (Must Avoid Before Coding)

| Lesson | Pitfall |
|---|---|
| DesignerCs-Immutable | Never modify Designer.cs Dispose method; also **never add `Dispose(bool)` override in `.cs` files** -- use `DisposeComponents()` instead |
| CodeProjectRegistration | New .cs files must be registered to .csproj |
| AutoProperty-Initializer | auto-property initializer causes CS1519 on MSBuild v4.0 |
| UI-Thread-Safety | Workflow events must use InvokeRequired |
| LiveMode-Exclusion | Live mode does not trigger AcquisitionCompletedSignal |
| Bounds-Sentinel-BlackScreen | Bounds sentinel value causes black screen |
| Assimp-RootNode | Assimp import must add entire scene.Root |
| UILight-Property | UILight must use OnColor/OffColor/State; case-sensitive "On" not "ON" |

## C# 7.3 Quick Reference (from CSharpStyle.md)

**Allowed**: `out var`, tuples, `nameof()`, `$""` interpolation, `??`, `?.`, `=>` expression body, `readonly struct`, `async/await`

**Prohibited (C# 8.0+)**: switch expressions, property pattern matching, `using` declarations, nullable reference types, `init` accessor, `record`, range operator, `$@""` interpolation with colon formatting

**Special trap**: Do NOT use `{expr:format}` inside `$""` interpolation (e.g., `{dt:yyyy-MM-dd}`). Extract to local variable first. This causes CS1739 in this project's build environment.

**WinForms designer**: `InitializeComponent()` must NOT contain `for`/`while`/`if`/`switch`/`foreach`. Expand loops to individual statements.

## Phase 0: Query -- Forced Knowledge Retrieval (Detailed Steps)

> **REMINDER**: Must display each Step (0.1 ~ 0.7) with its number, name, and output. Do NOT collapse into a single summary.

### Step 0.1: Read Index (Forced)
- **Action**: Use Read tool to read `Vicoding管理平台/LLMWiki/wiki/index/index.md`
- **Purpose**: Quickly locate Wiki pages relevant to the current requirement
- **Output**: List related module pages, API pages, decision records, lesson records

### Step 0.2: Read Decision Constraints ADR (Forced)
- **Action**: Read all ADRs under `Vicoding管理平台/LLMWiki/wiki/decisions/` related to involved modules
- **Purpose**: Get hard constraints -- these are deliberate architecture choices that must be followed
- **Output**: Decision constraint checklist (must follow, or explicitly override and record new ADR)

### Step 0.3: Read Historical Lessons (Forced)
- **Action**: Read all lessons under `Vicoding管理平台/LLMWiki/wiki/lessons/` related to involved modules
- **Purpose**: Get gate check items -- these are pitfalls others have hit, must confirm avoidance
- **Output**: Historical lesson gate checklist (must confirm avoidance before coding)

### Step 0.4: Read Module Architecture (Forced)
- **Action**: Read module pages under `Vicoding管理平台/LLMWiki/wiki/modules/` for involved modules
- **Purpose**: Understand module boundaries, core files, collaboration, known issues

### Step 0.5: Read API Context (Forced)
- **Action**: Read API pages under `Vicoding管理平台/LLMWiki/wiki/api/` for involved modules
- **Purpose**: Understand existing public interfaces, avoid reinventing or breaking contracts

### Step 0.6: Read History (Optional but Recommended)
- **Action**: Read `Vicoding管理平台/LLMWiki/raw/history/history.md`, search for related historical changes
- **Purpose**: Prevent new features from conflicting with historical ones

### Step 0.7: Code Graph Query (Forced -- ADR-025)
- **Action**: Use code-review-graph to query code-level relationships for involved modules (**Python NOT in system PATH -- must use conda myenv absolute path**; define once per session):
  ```powershell
  $pythonPath = "D:\ProgramData\miniconda3\envs\myenv\python.exe"
  $repoPath = "d:\A-A-项目类\04_研发项目\MRDF-2608 自适应焊接系统\workbudddy\AdaWeldSystem"
  $env:CRG_PARSE_EXECUTOR = "thread"
  ```
  1. `& $pythonPath -m code_review_graph status --repo $repoPath` -- verify graph database exists and is current
  2. `& $pythonPath -m code_review_graph search "<key symbol>" --repo $repoPath` -- locate symbols in the graph
  3. `& $pythonPath -m code_review_graph query callers_of "<target function>" --repo $repoPath` -- trace call chains (N-level depth)
  4. If graph is stale: `& $pythonPath -m code_review_graph build --repo $repoPath` to rebuild
- **Purpose**: Supplement LLMWiki architectural knowledge with code-level call chains, inheritance trees, and import dependencies that Wiki does not cover
- **Output**: Code-level relationship report (callers, callees, inheritance chain for involved symbols)
- **Fallback**: If code-review-graph is not installed or build fails, use Grep tool as fallback. The Step must still be executed and shown -- skipping is prohibited.
- **Constraint**: Per [[lessons/CodeGraphIntegrationGuide]], graph query results are immediate context only -- never write raw graph data into Wiki pages

### Step 0.8: Graph-Guided Code Reading (Forced -- ADR-025)
- **Action**: Before reading any code file, use code-review-graph to locate target symbols' file + line range, then read exact code blocks (**Python path $pythonPath from Step 0.7**):
  1. `& $pythonPath -m code_review_graph search "<key symbol>" --repo $repoPath` -- returns `file_path`, `line_start`, `line_end` for each class/function
  2. `& $pythonPath -m code_review_graph query file_summary "<file.cs>" --repo $repoPath` -- lists all symbols and their line ranges within a file
  3. Read the exact line range with `Read(offset=line_start, limit=line_end-line_start+1)` instead of reading the whole file
- **Purpose**: Upgrade the graph from "query call chains" to "code-reading navigator", narrowing the code file/code block read scope, reducing token waste and context pollution
- **Output**: Graph-guided code location map (`{file_path}::{symbol} -> lines {start}-{end}`)
- **Fallback**: If graph unavailable, use Grep (`grep -n "symbol" file.cs`) to locate line numbers, then still read exact ranges. Never switch to CodeGraph or other graph tools

## Phase 1: Plan -- Planning & Constraint Confirmation (Detailed Steps)

> **REMINDER**: Must display each Step (1.1 ~ 1.5) with its number, name, and output. Do NOT collapse into a single summary.

### Step 1.1: Requirement Parsing
- Summarize user core need in one sentence
- Confirm involved modules and boundaries

### Step 1.2: Change Scope Planning
- Compare with module boundaries in `wiki/modules/`, clarify modification and addition scope
- Follow minimal change principle

### Step 1.3: Identify New Decisions (ADR Forecast)
- Determine if coding involves new architecture choices
- If yes, flag for Phase 3 to create new `wiki/decisions/ADR-XXX-{Title}.md`

### Step 1.4: Identify Knowledge Ingest Points
- Forecast Wiki pages to update or create after coding
- Module docs? API docs? New ADR? New Lessons?

### Step 1.5: Skill Reference (Demoted to Auxiliary)
- For specialist role details, read `raw/skills/` corresponding Skill files
- **Note**: Skill files are reference, not command source. All coding decisions based on LLMWiki query results.

## Phase 2: Code -- Coding Execution (Detailed Steps)

> **REMINDER**: Must display each Step (2.1 ~ 2.5) with its number, name, and output. Do NOT collapse into a single summary.

### Step 2.1: Project Backup
- Use Bash to create a zip backup of the project:
  ```bash
  cd "D:/A-A-项目类/04_研发项目/MRDF-2608 自适应焊接系统/workbudddy"
  # Get timestamp for backup filename
  TIMESTAMP=$(date +%Y%m%d_%H%M%S)
  # Create backup (exclude bin/obj)
  cd AdaWeldSystem && tar -czf "../AdaWeldSystem_backup_${TIMESTAMP}.tar.gz" --exclude="bin" --exclude="obj" . && cd ..
  ```

### Step 2.2: Code Implementation
- **Continuously check** Phase 0 retrieved ADR constraints and Lessons gates during coding
- **When reading code, reuse Phase 0 Step 0.8 graph-guided reading**: locate target symbols' file + line range via `code-review-graph search` / `query file_summary`, then read exact code blocks with `Read(offset/limit)`, avoiding whole-file reads
- Follow C# code style (read `Vicoding管理平台/LLMWiki/raw/skills/AdaWeldsys_Skills/04-Style/CSharpStyle.md`)
- Minimal change, only modify directly related libraries and UI

### Step 2.3: Code Self-Review
- After implementation, check Phase 0 "Decision Constraint Checklist" and "Historical Lesson Gates" item by item
- **Mandatory Dispose check**: run `grep -rn "protected override void Dispose" --include="*.cs"` and verify that:
  - Designer.cs entries are unmodified (match standard generated pattern)
  - **No `.cs` file (excluding Designer.cs) contains `Dispose(bool)` override**
- Confirm no ADR or Lessons violations

### Step 2.4: .csproj Registration (If New Files Created)
- If new .cs files were created, **must** add `<Compile Include="..." />` entries to `AdaWeldSystem/AdaWeldSystem.csproj`
- Use Edit tool to add entries in the appropriate `<ItemGroup>`

### Step 2.5: Code Graph Impact Radius Verification (Forced -- ADR-025)
- **Action**: After code changes, verify impact radius using code graph (**Python path $pythonPath from Step 0.7**):
  1. `& $pythonPath -m code_review_graph impact --repo $repoPath --files "<changed_file.cs>"` -- get blast radius of changes
  2. `& $pythonPath -m code_review_graph query callers_of "<changed_public_method>" --repo $repoPath` -- trace all callers (N-level)
  3. Cross-check: every caller found by graph must be reviewed for compatibility
- **Purpose**: Catch indirect call chain breakages that Grep cannot detect (A->B->C, changing B breaks A but Grep on B won't find A)
- **Output**: Impact radius report (affected node count, caller chain depth, any broken references)
- **Fallback**: If unavailable, use Grep with manual multi-level tracing

## Phase 3: Ingest -- Forced Knowledge Deposition (Detailed Steps)

> **REMINDER**: Must display each Step (3.1 ~ 3.6) with its number, name, and output. Do NOT collapse into a single summary.

**This phase is mandatory, not optional. Coding without Ingest is considered incomplete.**

### Step 3.1: Update Module Docs
- Update `wiki/modules/` pages for involved modules
- Update core file list, module responsibilities, collaboration, known issues

### Step 3.2: Update API Docs
- Update `wiki/api/` pages for involved APIs, or create new pages
- Update public classes/methods/events, interface signatures, usage specs

### Step 3.3: Create or Update Decision Records (ADR)
- If Phase 1.3 forecasted new decisions, create `wiki/decisions/ADR-XXX-{Title}.md`

### Step 3.4: Create or Update Lesson Records
- If new pitfalls were discovered, create/update `wiki/lessons/{Title}.md`

### Step 3.5: Update Index
- Update `Vicoding管理平台/LLMWiki/wiki/index/index.md`
- Add new pages to corresponding category tables, update existing page summaries

### Step 3.6: Append Log
- Append to `Vicoding管理平台/LLMWiki/logs/log.md`
- Format: `## [YYYY-MM-DD HH:mm:ss] coding | description`
- **Timestamp must be obtained via Bash `date "+%Y-%m-%d %H:%M:%S"` or PowerShell `Get-Date -Format "yyyy-MM-dd HH:mm:ss"`, never guess**

## Phase 4: Lint -- Health Check (Detailed Steps)

> **REMINDER**: Must display each checklist item with its result. Do NOT collapse into a single summary.

### Checklist
- [ ] **Contradiction detection**: Do new Ingested contents conflict with existing wiki pages?
- [ ] **Stale detection**: Did code changes overturn old design decisions?
- [ ] **Orphan pages**: Do newly created pages have inbound links?
- [ ] **Red link detection**: Do `[[references]]` in pages point to existing pages?
- [ ] **Bidirectional links**: Do related pages reference each other?
- [ ] **Code drift**: Do `wiki/modules/` descriptions match current code?
- [ ] **Code graph drift (Forced -- ADR-025)**: Run `& $pythonPath -m code_review_graph dead-code --limit 10 --repo $repoPath` (Python path $pythonPath from Step 0.7) to check for newly created dead symbols. Run `& $pythonPath -m code_review_graph large-functions --limit 5 --repo $repoPath` to identify remaining refactoring candidates. Compare with Wiki module descriptions.

## Prohibited Behaviors (Forced)

1. **Prohibited**: Skip Phase 0 Query and code directly
2. **Prohibited**: Skip Phase 3 Ingest
3. **Prohibited**: Execute from memory without reading LLMWiki
4. **Prohibited**: Continue implementation after finding conflicts without user confirmation
5. **Prohibited**: Delete existing public interfaces without retaining compatibility layer
6. **Prohibited**: Leave red links (`[[reference]]` to non-existent pages) in Wiki
7. **Prohibited**: Create new .cs files without registering to .csproj
8. **Prohibited**: Execute Steps silently without showing Step-level output (Step number + name + findings)
9. **Prohibited**: Only show Phase-level summaries without Step-level breakdown
10. **Prohibited**: Skip Code Graph steps (Step 0.7 / Step 2.5 / Phase 4 graph drift). If tool unavailable, must execute with Grep fallback and explicitly state fallback reason

## WorkBuddy Tool Mapping

| Original Action | WorkBuddy Tool |
|---|---|
| Read file | Read tool |
| Write new file | Write tool |
| Edit existing file | Edit tool |
| Search file names | Glob tool |
| Search file contents | Grep tool |
| Execute shell command | Bash tool |
| Execute PowerShell | PowerShell tool |
| Get timestamp | Bash: `date "+%Y-%m-%d %H:%M:%S"` or PowerShell: `Get-Date -Format "yyyy-MM-dd HH:mm:ss"` |
| Create zip backup | Bash: `tar -czf backup.tar.gz --exclude=bin --exclude=obj .` |
| Phase tracking | TaskCreate / TaskUpdate / TaskList |
| Present results | present_files tool |

## Module Change Scope Control

| Change Type | Allowed Modification Scope | Prohibited Scope |
|---|---|---|
| Industrial camera | SmartRayCam/ and direct callers | Other modules |
| Image algorithm | EmguALG/ and direct callers | Other modules |
| 3D data processing | PointCloudData/ and direct callers | Other modules |
| General tech | FileOperate/, Comm/ | Other modules |
| Welding process | InteliWeld/, SqlLiteDatabase/AutoParamManager.cs | Other modules |
| Database | SqlLiteDatabase/ and direct callers | Other modules |
| Motion control | MotionControl/ and direct callers | Other modules |
| UI | UIDesign/ and directly called backend interfaces | Backend module internals |
